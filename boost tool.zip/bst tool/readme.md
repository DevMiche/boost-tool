Lo vendono per 30 $ 💀
<p align="center"> 
  <kbd>
<img src="https://cdn.discordapp.com/attachments/963114349877162004/992245751247806515/unknown.png" width="328"></img>
  </kbd>
</p>
  

1. Put ur webhook at hook = ""
2. and run main.py

<a id="features"></a>

---

### 〢 Features

#### Stealer

> FUD (Fully Undetectable)

> Password / Cookies
- Steal Saved Passwords
- Steal Brower Cookies

> Wallet Stealer
- Steal Metamask wallets
- Steal Exodus Wallet
- Steal Atomic Wallet

> Discord
- Steal Discord Tokens from browsers
- Steal Discord Token from discord, discordcanary, discordPTBa

> Gaming
- Steal Steam Launcher accounts
- Steal Nation Glory Launcher accounts

> File Stealer
- Search User PC for Passwords, 2Fa codes, tokens, wallets...
- Browsers: Opera, Chrome, Brave, Yandex, Edge

### 〢 Screenshots

<p align="center"> 
  <kbd>
<img src="https://cdn.discordapp.com/attachments/1022924956356591707/1023191911147778138/3346914e-af8e-4193-a534-9ffc72137323.png" width="328"></img>
  </kbd>
</p>

### 〢 Note

I am not responsible for any damages this software may cause. This was made for personal education.
### People who skidded/put a rat in it:

Caleb0205

